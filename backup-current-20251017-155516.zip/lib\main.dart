import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:ipi_deli_tour/firebase_options.dart';
import 'package:ipi_deli_tour/pages/auth_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Intentamos inicializar Firebase y si falla mostramos una pantalla de error
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    runApp(const MyApp());
  } catch (e, st) {
    // Si la inicialización falla, arrancamos una app mínima que muestra el error
    // y evita que la aplicación termine sin UI.
    // También imprimimos la traza en consola para facilitar debugging.
    // Nota: en producción podrías reportar esto a Sentry u otro servicio.
    // ignore: avoid_print
    print('Error initializing Firebase: $e');
    // ignore: avoid_print
    print(st);
    runApp(ErrorApp(error: e.toString()));
  }
}

class ErrorApp extends StatelessWidget {
  final String error;

  const ErrorApp({super.key, required this.error});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('Error')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Se produjo un error al iniciar Firebase:\n$error',
              style: const TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ipi Deli Tour',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.red,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Inter',
      ),
      home: const AuthPage(),
    );
  }
}
