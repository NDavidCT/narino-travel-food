class Food {
  String? imageUrl;
  String? name;
  double? price;
  String? description;

  Food({
    this.imageUrl,
    this.name,
    this.price,
    this.description,
  });
}
