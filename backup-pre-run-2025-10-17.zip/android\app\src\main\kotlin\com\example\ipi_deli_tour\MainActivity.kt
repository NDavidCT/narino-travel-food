package com.example.ipi_deli_tour

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
